import './Plugin.css';
import './CityInput.css'

function CityInput(){
    return (
        <div className='cityinput'>
            <input type="textarea"></input>
        </div>
    );
}
export default CityInput;
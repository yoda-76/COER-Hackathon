import './Plugin.css';
import './UserProfileRedirect.css'
import dp from "../assests/profileUploads/dp.webp";
import dp2 from "../assests/profileUploads/dp2.jpeg";
import dp3 from "../assests/profileUploads/dp3.jpeg";
import UserProfile from './UserProfile';
import Blogs from './Blogs';
function UserProfileRedirectD(props){
    console.log("testttt",props.city)
    return (
        <div className='userprofileredirect flex flex-col justify-content align-center'>
            <h3>{props.city}</h3>
            
            <UserProfile dp={dp}></UserProfile>
            <UserProfile dp={dp3}></UserProfile>
            <UserProfile dp={dp2}></UserProfile>

            
        </div>
    );
}
export default UserProfileRedirectD;
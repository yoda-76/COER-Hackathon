import './ToggleModes.css';
import './Plugin.css';

function ToggleModes(){
    return (
        <div className="toggleModes align-center justify-center flex flex-row">
        <p className="bg-white ">Route</p>
        <p className="bg-white ">Guide</p>
      </div>
    );
}
export default ToggleModes;


import './Plugin.css';
import './Tourist.css'
import TouristCard from './TouristCard';
function Tourist(){
    return (
        <div className='text-dark'>
            <TouristCard name="Yash" desc="ksdbfjkasdfjk askdfjk" area="kanpur"></TouristCard>
            </div>
    );
}
export default Tourist;